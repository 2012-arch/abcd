import React, { useState } from 'react';
import GameMap from './components/GameMap';
import GameOverlay from './components/GameOverlay';

const App = () => {
  const [userId] = useState(`user_${Math.random().toString(36).substr(2, 9)}`);
  const [gameId] = useState('default_game_1');
  const [role, setRole] = useState(null); // 'Runner' or 'Hunter'
  const [gameState, setGameState] = useState('lobby'); // 'lobby', 'headstart', 'active'

  if (!role) {
    return (
      <div className="h-screen w-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-4xl font-black mb-4 italic">HIDE & SEEK GPS</h1>
        <p className="text-slate-400 mb-8">Choose your side to enter the arena</p>
        <div className="grid grid-cols-1 gap-4 w-full max-w-xs">
          <button
            onClick={() => setRole('Runner')}
            className="bg-blue-600 p-6 rounded-2xl text-2xl font-bold hover:bg-blue-500 transition-colors"
          >
            🏃 I am a Runner
          </button>
          <button
            onClick={() => setRole('Hunter')}
            className="bg-red-600 p-6 rounded-2xl text-2xl font-bold hover:bg-red-500 transition-colors"
          >
            🎯 I am a Hunter
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen relative overflow-hidden">
      <GameMap
        role={role}
        userId={userId}
        gameId={gameId}
        gameSettings={{ center: { lat: 0, lng: 0 }, radius: 500 }}
      />
      <GameOverlay
        role={role}
        userId={userId}
        gameId={gameId}
        gameState={gameState}
      />
    </div>
  );
};

export default App;
