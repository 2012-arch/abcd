import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Circle, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { supabase } from '../lib/supabaseClient';
import { useLocation } from '../hooks/useLocation';

// Fix for default Leaflet marker icons in React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const GameMap = ({ role, userId, gameId, gameSettings }) => {
  const myLoc = useLocation();
  const [players, setPlayers] = useState([]);
  const [lastPingTime, setLastPingTime] = useState(null);

  useEffect(() => {
    // 1. Subscribe to real-time player updates
    const channel = supabase
      .channel('game_players')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'players' }, payload => {
        fetchPlayers();
      })
      .subscribe();

    fetchPlayers();

    return () => supabase.removeChannel(channel);
  }, []);

  const fetchPlayers = async () => {
    const { data } = await supabase
      .from('players')
      .select('*')
      .eq('game_id', gameId);
    if (data) setPlayers(data);
  };

  // Sync my location to Supabase
  useEffect(() => {
    if (myLoc.latitude && myLoc.longitude) {
      supabase
        .from('players')
        .upsert({
          id: userId,
          game_id: gameId,
          lat: myLoc.latitude,
          lng: myLoc.longitude,
          updated_at: new Date().toISOString()
        });
    }
  }, [myLoc.latitude, myLoc.longitude]);

  // Logic for "Pings": Hunters only see locations updated within the ping window
  const filteredPlayers = players.filter(p => {
    if (role === 'Hunter') {
      // In a real game, this would be controlled by the server/game state
      // For now, we check if the location is 'fresh' based on your ping rule
      const lastUpdate = new Date(p.updated_at);
      const now = new Date();
      const diffMinutes = (now - lastUpdate) / 1000 / 60;

      // Mocking the "Ping" window: if we are in a 'ping' phase, show them.
      // Otherwise, show their last known position.
      return true;
    }
    return p.id === userId; // Runners only see themselves
  });

  return (
    <MapContainer
      center={[myLoc.latitude || 0, myLoc.longitude || 0]}
      zoom={15}
      style={{ height: '100%', width: '100%' }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

      {/* Play Zone Boundary */}
      {gameSettings?.center && (
        <Circle
          center={[gameSettings.center.lat, gameSettings.center.lng]}
          radius={gameSettings.radius || 500}
          pathOptions={{ color: 'red', fillOpacity: 0.1 }}
        />
      )}

      {filteredPlayers.map(p => (
        <Marker key={p.id} position={[p.lat, p.lng]}>
          <Popup>{p.role === 'Runner' ? '🏃 Runner' : '🎯 Hunter'}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
};

export default GameMap;
