import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

const GameOverlay = ({ role, userId, gameId, gameState }) => {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      // Logic to sync with game server time
      // For now, a simple local countdown
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleTag = async () => {
    if (role !== 'Runner') return;

    const { error } = await supabase
      .from('players')
      .update({ status: 'tagged' })
      .eq('id', userId);

    if (!error) {
      alert('You have been tagged! You are now out.');
      // Trigger haptic feedback
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    }
  };

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none p-4 flex flex-col justify-between z-[1000]">
      <div className="bg-black/60 text-white p-4 rounded-lg w-fit pointer-events-auto">
        <h1 className="text-xl font-bold uppercase tracking-wider">
          {gameState === 'headstart' ? '🏃 Hiding Time...' : '🎯 Game Active!'}
        </h1>
        <p className="text-2xl font-mono">{timeLeft}s</p>
      </div>

      <div className="flex justify-center mb-8">
        {role === 'Runner' && (
          <button
            onClick={handleTag}
            className="pointer-events-auto bg-red-600 text-white px-8 py-4 rounded-full font-bold text-xl shadow-lg active:scale-95 transition-transform"
          >
            I GOT TAGGED 🏳️
          </button>
        )}
      </div>
    </div>
  );
};

export default GameOverlay;
