self.addEventListener('install', (event) => {
  console.log('SW installing');
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  console.log('SW activating');
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Basic fetch handler to keep the app alive
  event.respondWith(fetch(event.request));
});
